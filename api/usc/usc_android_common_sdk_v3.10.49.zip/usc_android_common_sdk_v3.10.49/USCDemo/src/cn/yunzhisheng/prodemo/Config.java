/**
 * Config.java [V 1.0.0]
 * classes : cn.yunzhisheng.prodemo.Config
 * liujunjie Create  at 2015-1-9  ??4:30:32
 */
package cn.yunzhisheng.prodemo;

/**
 * cn.yunzhisheng.prodemo.Config
 * 
 * @author liujunjie <br/>
 *         Create at 2015-1-9 ??4:30:32
 * 
 */
public class Config {

	public static final String appKey = "_appKey_";
	public static final String secret = "_secret_";
}
